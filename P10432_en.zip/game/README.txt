
title:      ApocalypseNow2018

author(s):  Salvador Roura


contact:    roura@cs.upc.edu

(c) Universitat Politècnica de Catalunya, 2018
